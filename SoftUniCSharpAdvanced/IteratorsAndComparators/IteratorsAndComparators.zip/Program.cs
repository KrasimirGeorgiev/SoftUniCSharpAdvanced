﻿using System;

namespace IteratorsAndComparators
{
    public class Program
    {
        static void Main(string[] args)
        {
            //var book1 = new Book("asdfa", 1986, "Tolstoi");
            //var book2 = new Book("asdfasdasfa", 1987, "Tolstoi");
            //var lib = new Library(book1, book2);
        }
    }
}
